"""Review probes for tutorials/DIMER_Whisper_Speech_Recognition_Workshop.ipynb (prefix ASR).

CPU-only, no model, no network. Extracts the notebook's carried files (CARRIED_FILES) into a temp
directory, imports the carried ``workshop.py`` and exercises the metric, noise and BYOD code paths
with synthetic audio. Evidence basis: direct execution of the carried source on CPU (stand-in data);
nothing here is a Whisper/Colab run.

usage: python run_probes.py <repo-root> <results.json>
"""

from __future__ import annotations

import ast
import hashlib
import io
import json
import sys
import tempfile
import zipfile
from pathlib import Path

NB = "tutorials/DIMER_Whisper_Speech_Recognition_Workshop.ipynb"


def carried(repo: Path) -> tuple[dict, dict, dict]:
    nb = json.loads((repo / NB).read_text(encoding="utf-8"))
    cells = {c["id"]: c for c in nb["cells"]}
    body = ast.parse("".join(cells["code-03"]["source"])).body
    files, hashes = (ast.literal_eval(n.value) for n in body[:2])
    return nb, files, hashes


def wav(seconds: float, rate: int = 16000, amp: float = 0.3, silent_fraction: float = 0.0, hz: float = 220) -> bytes:
    import numpy as np
    import soundfile as sf

    n = int(seconds * rate)
    t = np.arange(n) / rate
    x = (amp * np.sin(2 * np.pi * hz * t)).astype("float32")
    if silent_fraction:
        x[: int(n * silent_fraction)] = 0
    buf = io.BytesIO()
    sf.write(buf, x, rate, format="WAV", subtype="FLOAT")
    return buf.getvalue()


def zip_bytes(members: dict[str, bytes]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for name, data in members.items():
            z.writestr(name, data)
    return buf.getvalue()


def main() -> None:
    repo, out = Path(sys.argv[1]), Path(sys.argv[2])
    nb, files, hashes = carried(repo)
    cells = {c["id"]: "".join(c["source"]) for c in nb["cells"]}
    tmp = Path(tempfile.mkdtemp())
    for name, text in files.items():
        (tmp / name).parent.mkdir(parents=True, exist_ok=True)
        (tmp / name).write_text(text, encoding="utf-8")
    sys.path.insert(0, str(tmp))
    import numpy as np

    import workshop as w

    results: dict = {"repo_head_notebook_sha256": hashlib.sha256((repo / NB).read_bytes()).hexdigest()}

    # P01 (ASR-M2): the metric demo's printed alignment vs the worked interpretation.
    demo = w.score("pay my bill", "pay the bills now")
    printed = [(s["op"], s["reference"], s["hypothesis"]) for s in demo["alignment"] if s["op"] != "="]
    worked = cells["md-09"]
    claims_my_the = "my→the" in worked and "bill→bills" in worked
    explains_tie = "tie" in worked.lower()
    results["P01_metric_demo_alignment"] = {
        "counts": {k: demo[k] for k in ("S", "D", "I", "N")},
        "wer": demo["wer"],
        "printed_edits": printed,
        "worked_text_claims_my_the_bill_bills": claims_my_the,
        "worked_text_explains_tie_break": explains_tie,
        "finding": claims_my_the and printed != [("S", "my", "the"), ("S", "bill", "bills"), ("I", None, "now")]
        and not explains_tie,
    }

    # P02 (ASR-M1 context + md-05 claims): frozen sample statistics and reference provenance disclosure.
    sample = json.loads(files["sample.json"])
    recs = sample["records"]
    seconds = [r["seconds"] for r in recs]
    learner_text = "\n".join(src for cid, src in cells.items() if cid.startswith("md-"))
    low = learner_text.lower()
    discloses_asr = "google" in low.replace("google colab", "") and ("speech-to-text" in low or "asr" in low)
    results["P02_sample_and_reference_provenance"] = {
        "source_count": sample["source_count"],
        "eligible_count": sample["eligible_count"],
        "roles": {role: sum(r["role"] == role for r in recs) for role in ("evaluation", "activity")},
        "total_seconds": round(sum(seconds), 3),
        "min_seconds": round(min(seconds), 3),
        "max_seconds": round(max(seconds), 3),
        "example_reference": recs[3]["reference"],
        "notebook_discloses_references_are_asr_output": discloses_asr,
        "workshop_py_summary_discloses": "google" in files["workshop.py"].split("def export_report")[1][:2500].lower(),
        "finding": not discloses_asr,
    }

    # P03 (ASR-m2): noise construction: shared gain, achieved SNR, and what "SNR" is measured over.
    rng = np.random.default_rng(0)
    speech = (0.3 * np.sin(2 * np.pi * 220 * np.arange(32000) / 16000)).astype("float32")
    speech[:16000] = 0  # half silence, as in a pause before speaking
    gains = {}
    for snr in (5, 10, 20):
        a, b, meta = w.noise_pair(speech, "probe-id", snr)
        active = slice(16000, 32000)
        seg = 20 * np.log10(np.sqrt(np.mean(a[active].astype(float) ** 2)) / np.sqrt(np.mean((b[active].astype(float) - a[active]) ** 2)))
        gains[snr] = {"gain": meta["gain"], "actual_snr": round(meta["actual_snr"], 4), "speech_segment_snr": round(float(seg), 3),
                      "max_abs": float(max(np.abs(a).max(), np.abs(b).max()))}
    _ = rng
    md11 = cells["md-11"]
    results["P03_noise_pair"] = {
        "per_snr": gains,
        "gain_invariant_across_snr": len({round(v["gain"], 12) for v in gains.values()}) == 1,
        "prose_says_speech_power": "speech power" in md11,
        "prose_mentions_pauses_or_whole_recording": "whole recording" in md11 or "pauses" in md11,
        "finding": "speech power" in md11 and not ("whole recording" in md11 or "pauses" in md11),
    }

    # P04 (ASR-M3): unlabelled multi-clip BYOD keeps no file name in its records / exported rows.
    work = tmp / "byod"
    work.mkdir()
    z = work / "clips.zip"
    z.write_bytes(zip_bytes({"zeta_call.wav": wav(2.0, hz=300), "alpha_call.wav": wav(3.0, hz=400)}))
    records = w.load_byod(z, work / "validation")
    rs = w.run_stage.__code__.co_consts
    results["P04_byod_identifiers"] = {
        "ids": [r["id"] for r in records],
        "record_keys_with_file": [k for k in records[0] if "file" in k],
        "run_stage_carries_file_into_rows": '"file"' in files["workshop.py"].split("def run_stage")[1],
        "finding": not any("file" in k for k in records[0]),
    }
    _ = rs

    # P05 (ASR-m1): a bad clip inside a multi-clip ZIP — does the refusal name the clip?
    bad = work / "bad.zip"
    bad.write_bytes(zip_bytes({"a.wav": wav(2.0, hz=300), "b.wav": wav(2.0, hz=500), "short.wav": wav(0.4, hz=700)}))
    try:
        w.load_byod(bad, work / "v2")
        msg = None
    except ValueError as exc:
        msg = str(exc)
    extra = work / "extra.zip"
    extra.write_bytes(zip_bytes({"a.wav": wav(2.0), "__MACOSX/._a.wav": b"x", "notes.txt": b"hi"}))
    try:
        w.load_byod(extra, work / "v3")
        msg2 = None
    except ValueError as exc:
        msg2 = str(exc)
    results["P05_byod_refusal_names_member"] = {
        "short_clip_message": msg,
        "short_clip_named": bool(msg) and "short.wav" in msg,
        "undeclared_member_message": msg2,
        "undeclared_member_named": bool(msg2) and ("notes.txt" in msg2 or "__MACOSX" in msg2),
        "finding": not (bool(msg) and "short.wav" in msg) or not (bool(msg2) and ("notes.txt" in msg2 or "__MACOSX" in msg2)),
    }

    # P06 (ASR-m3): per-cell provenance metadata vs the carried workshop.py digest.
    cell_meta = next(c for c in nb["cells"] if c["id"] == "code-03")["metadata"].get("dimer", {}).get("sources", {})
    results["P06_cell_metadata_digest"] = {
        "cell_metadata_workshop_py": cell_meta.get("workshop.py"),
        "carried_hash_workshop_py": hashes["workshop.py"],
        "generated_from_workshop_py": nb["metadata"]["dimer"]["generated_from"]["sources"]["workshop.py"],
        "finding": bool(cell_meta) and cell_meta != nb["metadata"]["dimer"]["generated_from"]["sources"],
    }

    # P07 (ASR-m4): glossary present?
    results["P07_glossary"] = {"has_glossary_heading": any("glossary" in s.lower() for s in cells.values()),
                               "finding": not any("glossary" in s.lower() for s in cells.values())}

    # P08 (ASR-m5): can the learner hear the best/worst examples it is told to inspect?
    show = cells["code-04"].split("def show_results")[1]
    results["P08_listen_to_selected_examples"] = {
        "plays_only_first_recording": "listen_" in show and "audio_path" not in show,
        "finding": "audio_path" not in show,
    }

    # P09 (sanity, non-finding): export_report round-trips synthetic rows without a model.
    rows = []
    for i, (ref, hyp) in enumerate([("pay my bill", "pay my bill"), ("check my balance", "check balance now")]):
        rows.append({"id": str(i), "role": "evaluation", "condition": "clean", "seconds": 2.0, **w.score(ref, hyp),
                     "inference_seconds": 0.1, "truncated": False, "sequence_tokens": 5, "failure": None})
    metrics = {"clean": w.aggregate(rows)}
    archive = w.export_report(tmp / "report", rows, metrics, {"probe": True})
    results["P09_export_roundtrip"] = {"zip": archive.name, "wer": metrics["clean"]["wer"],
                                       "members": sorted(zipfile.ZipFile(archive).namelist()), "finding": False}

    results["findings_open"] = sorted(k for k, v in results.items() if isinstance(v, dict) and v.get("finding"))
    out.write_text(json.dumps(results, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
    print(json.dumps(results["findings_open"]))


if __name__ == "__main__":
    main()
