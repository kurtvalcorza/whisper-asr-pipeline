"""P1: every third-party module imported by a code cell of the notebook (outside the carried module cell, and
inside it at module level), compared with the notebook's own PINS list and with the stdlib."""
import ast, json, re, sys
nb_path, out = sys.argv[1], sys.argv[2]
nb = json.load(open(nb_path))
cells = nb['cells']
src3 = next(''.join(c['source']) for c in cells if 'PINS = [' in ''.join(c['source']))
pins = re.findall(r"'([A-Za-z0-9_.-]+)==([^']+)'", re.search(r'PINS = \[(.*?)\]', src3, re.S).group(1))
pinned = {p[0].lower().replace('_', '-') for p in pins}
MODULE_TO_DIST = {'soundfile': 'soundfile', 'datasets': 'datasets', 'torch': 'torch', 'torchaudio': 'torchaudio', 'transformers': 'transformers',
                  'numpy': 'numpy', 'peft': 'peft', 'pandas': 'pandas', 'safetensors': 'safetensors', 'huggingface_hub': 'huggingface-hub', 'accelerate': 'accelerate', 'google': 'google-colab (Colab only)'}
res = {'pins': pins, 'per_cell': {}, 'unpinned_third_party': {}}
for i, c in enumerate(cells):
    if c['cell_type'] != 'code':
        continue
    try:
        tree = ast.parse(''.join(c['source']))
    except SyntaxError:
        continue
    mods = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            mods |= {a.name.split('.')[0] for a in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            mods.add(node.module.split('.')[0])
    third = sorted(m for m in mods if m not in sys.stdlib_module_names)
    if third:
        res['per_cell'][i] = third
    for m in third:
        dist = MODULE_TO_DIST.get(m, m)
        if dist not in pinned and not dist.startswith('google'):
            res['unpinned_third_party'].setdefault(m, []).append(i)
print(json.dumps(res, indent=1)); json.dump(res, open(out, 'w'), indent=1)
