"""P2: exec the notebook's install cell (cell 3) in a kernel stand-in that has already imported a
numpy differing from the pin, as hosted images do (Colab/Kaggle ship numpy 2.x). PINS is narrowed to
the numpy pin so no torch is installed; the guard logic and message are the notebook's own."""
import json, re, sys
import numpy  # pre-imported, version != 1.26.4
nb = json.load(open(sys.argv[1]))
src = ''.join(nb['cells'][3]['source'])
pins_block = re.search(r"PINS = \[.*?\]\n", src, re.S).group(0)
narrowed = src.replace(pins_block, "PINS = ['numpy==1.26.4']\n").split('import torch, numpy, pandas')[0]
before = numpy.__version__
try:
    exec(narrowed, {'__name__': '__main__'})
    out = {'outcome': 'continued'}
except RuntimeError as exc:
    out = {'outcome': 'RuntimeError', 'message': str(exc)}
out['numpy_loaded_before'] = before
out['original_pins'] = re.findall(r"'([^']+==[^']+)'", pins_block)
print(json.dumps(out, indent=1)); json.dump(out, open(sys.argv[2], 'w'), indent=1)
