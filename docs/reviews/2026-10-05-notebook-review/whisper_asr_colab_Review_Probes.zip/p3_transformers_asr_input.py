"""P3: read transformers==4.52.1 (wheel from PyPI, read as text, not imported) to see how the ASR pipeline
decodes a str input. The BYOD branch passes the uploaded file's *name* to pipe.transcribe, while the sample
branch passes a soundfile-decoded waveform."""
import json, re, sys, zipfile, hashlib
whl, nb_path, out = sys.argv[1:4]
z = zipfile.ZipFile(whl)
asr = z.read('transformers/pipelines/automatic_speech_recognition.py').decode().splitlines()
au = z.read('transformers/pipelines/audio_utils.py').decode().splitlines()
pick = lambda lines, pat: [f'{i+1}: {l.strip()}' for i, l in enumerate(lines) if re.search(pat, l)]
nb = json.load(open(nb_path))
c9 = next(''.join(c['source']) for c in nb['cells'] if 'USE_BYOD = False' in ''.join(c['source']))
res = {'wheel_sha256': hashlib.sha256(open(whl, 'rb').read()).hexdigest(),
       'asr_pipeline_str_branch': pick(asr, r'isinstance\(inputs, str\)|startswith\("http|ffmpeg_read\(inputs'),
       'audio_utils_ffmpeg': pick(au, r'def ffmpeg_read|ffmpeg was not found but is required to load'),
       'notebook_byod_audio_input': re.findall(r'^\s*audio_input = (.+)$', c9, re.M),
       'notebook_pins_ffmpeg': 'ffmpeg' in ''.join(''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'code' and 'PINS' in ''.join(c['source']))}
print(json.dumps(res, indent=1)); json.dump(res, open(out, 'w'), indent=1)
