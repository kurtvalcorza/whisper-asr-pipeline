"""P4: cell 9's BYOD branch exec'd with a google.colab stand-in (the stand-in also writes the file to the working
directory, as Colab's files.upload does), then cell 11's validate_inputs, on WAV / FLAC / stereo / OGG /
MP3-named-garbage / empty / cancelled uploads; records what audio_input the model would receive.
P5: the carried word_error_rate on the recorded transcript and reference, plus normalisation cases."""
import io, json, os, sys, types, tempfile, importlib
from pathlib import Path
import numpy as np, soundfile as sf
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('whisper_asr_pipeline'); pkg.__path__ = [str(repo / 'src/whisper_asr_pipeline')]
sys.modules['whisper_asr_pipeline'] = pkg
P = importlib.import_module('whisper_asr_pipeline.pipeline')
nb = json.loads((repo / 'tutorials/whisper_asr_colab.ipynb').read_text())
c9 = next(''.join(c['source']) for c in nb['cells'] if 'USE_BYOD = False' in ''.join(c['source']))
c11 = next(''.join(c['source']) for c in nb['cells'] if 'oversized-chunk-probe' in ''.join(c['source']))
branch = '\n'.join(l[4:] for l in c9.split('if USE_BYOD:\n', 1)[1].split('\nelse:', 1)[0].splitlines())
tailc9 = c9.split('sample_sha256 = ', 1)[1]
def enc(fmt, stereo=False, sr=16000):
    t = np.arange(sr * 2) / sr; y = 0.1 * np.sin(2 * np.pi * 220 * t).astype('float32')
    if stereo: y = np.stack([y, y], axis=1)
    b = io.BytesIO(); sf.write(b, y, sr, format=fmt); return b.getvalue()
cases = {'wav_mono': {'a.wav': enc('WAV')}, 'flac_stereo_44k': {'b.flac': enc('FLAC', True, 44100)}, 'ogg': {'c.ogg': enc('OGG')},
         'text_named_mp3': {'d.mp3': b'not audio at all'}, 'empty_wav': {'e.wav': b''}, 'cancelled': {}, 'two_files': {'f.wav': enc('WAV'), 'g.wav': enc('WAV')}}
work = Path(tempfile.mkdtemp()); os.chdir(work)
res = {'P4': {}}
for name, up in cases.items():
    for f, b in up.items(): Path(f).write_bytes(b)
    colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda u=up: dict(u))
    sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    g = {'sf': sf, 'io': io, 'np': np, 'REFERENCE_TEXT': '', 'hashlib': __import__('hashlib')}
    stage = 'cell9'
    try:
        exec(branch, g); exec('sample_sha256 = ' + tailc9.split('\nprint(')[0], g); stage = 'cell11'
        im = P.validate_inputs(g['audio_input'], language='en', task='transcribe', names=[g['sample_name']])
        res['P4'][name] = {'outcome': 'accepted', 'audio_input_passed_to_model': repr(g['audio_input'])[:60], 'manifest_input': im['inputs'][0],
                           'soundfile_seconds': round(len(g['waveform']) / g['sampling_rate'], 2), 'files_uploaded': len(up)}
    except BaseException as exc:
        res['P4'][name] = {'outcome': 'refused', 'stage': stage, 'error': f'{type(exc).__name__}: {exc}'[:200]}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
try:
    exec('from google.colab import files', {}); res['P4']['outside_colab'] = 'no error'
except Exception as exc:
    res['P4']['outside_colab'] = f'{type(exc).__name__}: {exc}'
ref = 'MISTER QUILTER IS THE APOSTLE OF THE MIDDLE CLASSES AND WE ARE GLAD TO WELCOME HIS GOSPEL'
hyp = 'Mr. Quilter is the apostle of the middle classes, and we are glad to welcome his gospel.'
res['P5'] = {'recorded_pair': {'wer': round(P.word_error_rate(ref, hyp), 4), 'record': 0.0588},
             'normalisation_cases': {f'{a!r} vs {b!r}': round(P.word_error_rate(a, b), 3) for a, b in [
                 ('i want to check my balance', 'I want to check my balance.'), ('pay 100 dollars', 'pay one hundred dollars'),
                 ('pay $100', 'pay 100 dollars'), ("it's late", 'it’s late'), ('ok', 'okay'), ('', 'thank you')]}}
print(json.dumps(res, indent=1, default=str)); (out / 'p4_p5.json').write_text(json.dumps(res, indent=1, default=str))
