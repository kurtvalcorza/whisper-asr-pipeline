"""P2: cell 9's BYOD branch, its clip-length filter and split, then cell 11's per-clip validation, exec'd with
stand-ins for google.colab, datasets and torchaudio (all clips are written at 16 kHz, so the torch resample is
never reached). Shows what happens to clips longer than MAX_CHUNK_LENGTH_S, the minimum BYOD size at the
default TRAIN_CLIPS/EVAL_CLIPS, and the loader's error messages."""
import io, json, os, sys, types, tempfile, importlib, contextlib
from pathlib import Path
import numpy as np, soundfile as sf
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('whisper_asr_pipeline'); pkg.__path__ = [str(repo / 'src/whisper_asr_pipeline')]
sys.modules['whisper_asr_pipeline'] = pkg
P = importlib.import_module('whisper_asr_pipeline.pipeline')
for name in ('torchaudio', 'datasets'):
    m = types.ModuleType(name); m.Audio = object; m.load_dataset = None; sys.modules[name] = m
nb = json.loads((repo / 'tutorials/whisper_asr_finetune_colab.ipynb').read_text())
c9 = next(''.join(c['source']) for c in nb['cells'] if 'USE_BYOD = False' in ''.join(c['source']))
c11 = next(''.join(c['source']) for c in nb['cells'] if 'oversized-chunk-probe' in ''.join(c['source']))
c9 = c9.replace('USE_BYOD = False', 'USE_BYOD = True')
def wav(seconds):
    b = io.BytesIO(); sf.write(b, (0.05 * np.random.default_rng(int(seconds * 10)).standard_normal(int(16000 * seconds))).astype('float32'), 16000, format='WAV'); return b.getvalue()
def upload(n_short, n_long=0, text='check my balance', missing=False, no_csv=False, empty_text_at=None):
    files, rows = {}, ['file,text']
    for i in range(n_short + n_long):
        name = f'clip{i:04d}.wav'; files[name] = wav(2.0 if i < n_short else 35.0)
        rows.append(f"{name},{'' if i == empty_text_at else text}")
    if missing: rows.append('ghost.wav,hello')
    if not no_csv: files['transcripts.csv'] = ('\n'.join(rows) + '\n').encode()
    return files
cases = {'default_sizes_603_clips_3_longer_than_30s': upload(600, 3), 'default_sizes_499_clips': upload(499), 'default_sizes_120_clips': upload(120),
         'no_csv_in_upload': upload(10, no_csv=True), 'csv_names_missing_file': upload(600, missing=True), 'empty_transcript': upload(600, empty_text_at=5)}
os.chdir(tempfile.mkdtemp())
res = {}
for name, up in cases.items():
    colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda u=up: dict(u))
    sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    g = {k: getattr(P, k) for k in ('MAX_CHUNK_LENGTH_S', 'MIN_CHUNK_LENGTH_S', 'TASKS', 'INPUT_SCHEMA', 'MODEL_ID', 'MODEL_REVISION', 'validate_inputs')}
    g.update(os=os, torch=types.SimpleNamespace())
    stage = 'cell9'
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            exec(c9, g); stage = 'cell11'; exec(c11, g)
        csv_rows = sum(1 for k in up if k.endswith('.wav'))
        res[name] = {'outcome': 'accepted', 'clips_in_csv': csv_rows, 'clips_after_filter': len(g['clips']), 'silently_dropped': csv_rows - len(g['clips']),
                     'validated': len(g['input_manifest']['inputs']), 'findings': [f['input'] for f in g['input_manifest']['findings']]}
    except BaseException as exc:
        res[name] = {'outcome': 'refused', 'stage': stage, 'error': f'{type(exc).__name__}: {exc}'[:200]}
res['cancelled_dialog'] = None
colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda: {}); sys.modules['google.colab'] = colab
try:
    g = {'os': os}; exec(c9, g); res['cancelled_dialog'] = 'no error'
except BaseException as exc:
    res['cancelled_dialog'] = f'{type(exc).__name__}: {exc}'[:120]
res['prose_claims'] = {'cell10': 'nothing is truncated; an offending clip is a rejection finding and stops the run',
                       'tutorials_README': '30 s ceiling enforced, never truncated'}
res['P3_wer_normalisation'] = {f'{a!r} vs {b!r}': round(P.word_error_rate(a, b), 3) for a, b in [
    ('I want to check my balance.', 'i want to check my balance'), ('can you transfer 50 dollars', 'can you transfer fifty dollars'),
    ('my card was declined', 'My card was declined!'), ('I need to pay my bill', "I'd need to pay my bill")]}
print(json.dumps(res, indent=1)); (out / 'p2_p3.json').write_text(json.dumps(res, indent=1))
