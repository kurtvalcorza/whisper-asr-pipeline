"""P5: name lifecycle across code cells (static, AST). For the documented re-run entry point (cell 9: 'set
USE_BYOD = True in Section 4 and re-run from that cell'; the 'Try next' fields also live in cells 9 and 17),
report every name a later cell reads that is defined only before the entry point and deleted by `del` after
a full Run all, i.e. a NameError on the documented re-run."""
import ast, json, sys
nb = json.load(open(sys.argv[1])); entry = int(sys.argv[3]) if len(sys.argv) > 3 else 9
cells = {i: ''.join(c['source']) for i, c in enumerate(nb['cells']) if c['cell_type'] == 'code'}
info = {}
for i, s in cells.items():
    t = ast.parse(s)
    stores, loads, dels = set(), set(), set()
    for n in ast.walk(t):
        if isinstance(n, ast.Name):
            (stores if isinstance(n.ctx, ast.Store) else dels if isinstance(n.ctx, ast.Del) else loads).add(n.id)
        elif isinstance(n, (ast.FunctionDef, ast.ClassDef)):
            stores.add(n.name)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            stores |= {(a.asname or a.name).split('.')[0] for a in n.names}
    info[i] = {'stores': stores, 'loads': loads, 'dels': dels}
deleted_after_run = set().union(*[v['dels'] for v in info.values()])
hazards = []
for i in sorted(c for c in cells if c >= entry):
    defined_from_entry = set().union(*[info[j]['stores'] for j in cells if entry <= j < i]) if i > entry else set()
    # a name read in cell i and not stored anywhere in cell i (approximation of 'read before store'), not re-defined between the entry point and i,
    # defined before the entry point, and deleted somewhere in a full run
    for name in sorted(info[i]['loads'] & deleted_after_run):
        before_entry = any(name in info[j]['stores'] for j in cells if j < entry)
        if before_entry and name not in defined_from_entry and name not in info[i]['stores']:
            hazards.append({'cell': i, 'name': name, 'defined_in': [j for j in cells if name in info[j]['stores']],
                            'deleted_in': [j for j in cells if name in info[j]['dels']]})
res = {'entry_cell': entry, 'deleted_names': sorted(deleted_after_run), 'nameerror_on_rerun': hazards}
print(json.dumps(res, indent=1)); json.dump(res, open(sys.argv[2], 'w'), indent=1)
